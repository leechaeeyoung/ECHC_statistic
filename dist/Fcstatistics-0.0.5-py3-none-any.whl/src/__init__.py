from .fc import Mean, MVar, bayes_theorem, bi_coefficient
# 라이브러리 모듈 이름설정 파일